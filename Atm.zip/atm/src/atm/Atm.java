
 package atm;
import java.sql.*;
public class Atm {
    
public boolean giris(String tc,int sifre ){
    boolean sonuc=false;
    
    
    
    return sonuc;
}
    public static void main(String[] args) {
        
        
        
    }
    
}

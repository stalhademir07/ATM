
package atm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class baglantı {
    
    static Connection conn;
    public Connection baglan(){
        return conn;
    }
    public baglantı () {
        try{
           // conn=DriverManager.getConnection("jdbc:derby://localhost:1527/bankaATM","root","123");
           conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/banka?useUnicode=true&characterEncoding=UTF-8","std07","1234");
        }catch(SQLException exp){
            System.out.println("Veri tabanı bağlantısı kurulamadı");
            System.out.println(exp.getMessage());
        }
    }
    
}
